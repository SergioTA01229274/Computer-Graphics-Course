var db = {
    "Mercury": {
        type: "planet",
        name: "Mercury",
        origin: "Named for the messenger of the Roman gods",
        description: "Zipping around the sun in only 88 days, Mercury is the closest planet to the sun, and it's also the smallest, only a little bit larger than Earth's moon.",
        discovery: "Known to the ancient Greeks and visible to the naked eye",
        diameter: "4,878 km",
        orbit: "88 Earth days",
        day: "58.6 Earth days"
    },
    "Venus": {
        type: "planet",
        name: "Venus",
        origin: "Named for the Roman goddess of love and beauty",
        description: "The second planet from the sun, Venus is Earth's twin in size. Radar images beneath its atmosphere reveal that its surface has various mountains and volcanoes.",
        discovery: "Known to the ancient Greeks and visible to the naked eye",
        diameter: "12,104 km",
        orbit: "225 Earth days",
        day: "241 Earth days"
    },
    "Earth": {
        type: "planet",
        name: "Earth",
        origin: "Name originates from Die Erde, the German word for the ground",
        description: "The third planet from the sun, Earth is a waterworld, with two-thirds of the planet covered by ocean. It's the only world known to harbor life.",
        discovery: "Humanity's planet",
        diameter: "12,760 km",
        orbit: "365.24 days",
        day: "23 hours, 56 minutes"
    },
    "Mars": {
        type: "planet",
        name: "Mars",
        origin: "Named for the Roman god of war",
        description: "The fourth planet from the sun is Mars, and it's a cold, desert-like place covered in dust. This dust is made of iron oxides, giving the planet its iconic red hue.",
        discovery: "Known to the ancient Greeks and visible to the naked eye",
        diameter: "6,787 km",
        orbit: "687 Earth days",
        day: "24 hours, 37 minutes"
    },
    "Jupiter": {
        type: "planet",
        name: "Jupiter",
        origin: "Named for the ruler of the Roman gods",
        description: "The fifth planet from the sun, Jupiter is a giant gas world that is the most massive planet in our solar system — more than twice as massive as all the other planets combined, according to NASA.",
        discovery: "Known to the ancient Greeks and visible to the naked eye",
        diameter: "139,822 km",
        orbit: "11.9 Earth years",
        day: "9.8 Earth hours"
    },
    "Saturn": {
        type: "planet",
        name: "Saturn",
        origin: "Named for Roman god of agriculture",
        description: "The sixth planet from the sun, Saturn is known most for its rings. When polymath Galileo Galilei first studied Saturn in the early 1600s, he thought it was an object with three parts: a planet and two large moons on either side.",
        discovery: "Known to the ancient Greeks and visible to the naked eye",
        diameter: "120,500 km",
        orbit: "29.5 Earth years",
        day: "10.5 Earth hours"
    },
    "Uranus": {
        type: "planet",
        name: "Uranus",
        origin: "Named for the personification of heaven in ancient myth",
        description: "The seventh planet from the sun, Uranus is an oddball. It has clouds made of hydrogen sulfide, the same chemical that makes rotten eggs smell so foul.",
        discovery: "1781 by William Herschel",
        diameter: "51,120 km",
        orbit: "84 Earth years",
        day: "18 Earth hours"
    },
    "Neptune": {
        type: "planet",
        name: "Neptune",
        origin: "Named for the Roman god of water",
        description: "The eighth planet from the sun, Neptune is about the size of Uranus and is known for supersonic strong winds. Neptune is far out and cold.",
        discovery: "1846",
        diameter: "49,530 km",
        orbit: "165 Earth years",
        day: "19 Earth hours"
    },
    "Pluto": {
        type: "planet",
        name: "Pluto (dwarf planet)",
        origin: "Named for the Roman god of the underworld, Hades",
        description: "Once the ninth planet from the sun, Pluto is unlike other planets in many respects. It is smaller than Earth's moon; its orbit is highly elliptical.",
        discovery: "1930 by Clyde Tombaugh",
        diameter: "2,301 km",
        orbit: "248 Earth years",
        day: "6.4 Earth days"
    },
    "Sun": {
        type: "sun",
        name: "Sun",
        description: "The sun is a star, a hot ball of glowing gases at the heart of our solar system. Its influence extends far beyond the orbits of distant Neptune and Pluto.",
        diameter: "139,0473 km",
        temperature: "5,537 degrees Celsius",
        composition: "Hydrogen, helium" 
    },
    "Moon": {
        type: "moon",
        name: "Moon",
        description: "Our moon makes Earth a more livable planet by moderating our home planet's wobble on its axis, leading to a relatively stable climate, and creating a tidal rhythm that has guided humans for thousands of years.",
        distance: "384,633 km",
        day: "27 Earth days",
        minTemp: "-232 degrees Celcius",
        maxTemp: "122 degrees Celcius"
    },
    "Asteroid": {
        type: "asteroid",
        name: "Comet Halley",
        description:  "Halley’s Comet, the most known comet, is named after English astronomer Edmond Halley who first determined its period of orbit. It was the first comet to be recognized as having a periodic orbit.",
        orbit: "It is known as a periodic comet (or short term comet) because the time it takes to orbit the Sun is less than 200 years",
        seen: "It can be seen with the naked eye every 76 yeras",
        lastSeen: "1986",
        nextSeen: "2061",
        comet: "Comets are cosmic snowballs of frozen gases, rock and dust that orbit the Sun."
    },
    "Satellite": {
        type: "satellite",
        name: "International Space Station",
        description:  "The International Space Station (ISS) is the largest single structure humans ever put into space. Its main construction was completed between 1998 and 2011",
        flies: "The space station flies at an average altitude of 248 miles (400 kilometers) above Earth. It circles the globe every 90 minutes at a speed of about 17,500 mph (28,000 km/h). In one day, the station travels about the distance it would take to go from Earth to the moon and back.",
        allies: "As of January 2018, 230 individuals from 18 countries have visited the International Space Station. Top participating countries include the United States (145 people) and Russia (46 people)",
        crew: "Crews aboard the ISS are assisted by mission control centers in Houston and Moscow and a payload control center in Huntsville, Ala"

    },
    "Star1": {
        type: "star",
        name: "Nebula",
        description:  "A nebula is a giant cloud of dust and gas in space. Some nebulae (more than one nebula) come from the gas and dust thrown out by the explosion of a dying star, such as a supernova. Other nebulae are regions where new stars are beginning to form.",
    },
    "Star2": {
        type: "star",
        name: "Universe",
        description:  "The sum total of all existence. It is the entirety of time, space, matter and energy that began with the big bang.",
    },
    "Star3": {
        type: "star",
        name: "Galaxy",
        description:  "A galaxy is a huge collection of gas, dust, and billions of stars and their solar systems, all held together by gravity.",
    },
    "Star4": {
        type: "star",
        name: "Big Bang",
        description:  "The big bang is how astronomers explain the way the universe began. It is the idea that the universe began as just a single point, then expanded and stretched to grow as large as it is right now (and it could still be stretching).",
    },
    "Star5": {
        type: "star",
        name: "Milky Way",
        description:  "The Milky Way Galaxy is most significant to humans because it is home sweet home. But when it comes down to it, our galaxy is a typical barred spiral, much like billions of other galaxies in the universe. This is the galaxy in which the sun and other planets orbit by.",
    },
    "Star6": {
        type: "star",
        name: "Black Hole",
        description:  "A black hole is a place in space where gravity pulls so much that even light can't get out. The gravity is so strong because matter has been squeezed into a tiny space. Scientists think the smallest black holes formed when the universe began. Stellar black holes are made when the center of a very big star falls in upon itself, or collapses. When this happens, it causes a supernova.",
        formation: ""
    }
}