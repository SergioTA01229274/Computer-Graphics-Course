function windowEventListener(event)
{
    resizeCanvas();
    renderer.setSize(canvas.width, canvas.height);
    camera.aspect = canvas.width / canvas.height;
    camera.updateProjectionMatrix();
    camera2.aspect = canvas.width / canvas.height;
    camera2.updateProjectionMatrix();
}

// Resets the canvas dimensions to match window
function resizeCanvas() 
{
    canvas.width = 0.75*window.innerWidth;
    canvas.height = 0.75*window.innerHeight;
}

function onClick( event ) {
	selected.material.opacity = 1.;
	event.preventDefault();
	var x = event.clientX;
	var y = event.clientY;

	var rect = event.target.getBoundingClientRect();
	mouse.x = 2 * (x - rect.left) / canvas.width - 1;
	mouse.y = 2 * (rect.top - y) / canvas.height + 1;
	raycaster.setFromCamera( mouse, cameraOnUse );
	var intersects = raycaster.intersectObjects( sceneOnUse.children, true);

	if (intersects.length > 0){
		selected = intersects[0].object;
		intersects[0].object.material.opacity = 0.6;
		console.log(selected.constructor);
		switch (selected.constructor){
			case Mercury:
				cm.selectObject("Mercury");
				camera3.position.x = camera3Positions[1][0];
				camera3.position.y = camera3Positions[1][1];
				camera3.position.z = camera3Positions[1][2];
				
				break;
			case Venus:
				cm.selectObject("Venus");
				camera3.position.x = camera3Positions[2][0];
				camera3.position.y = camera3Positions[2][1];
				camera3.position.z = camera3Positions[2][2];
				
				break;
			case Earth:
				cm.selectObject("Earth");
				camera3.position.x = camera3Positions[3][0];
				camera3.position.y = camera3Positions[3][1];
				camera3.position.z = camera3Positions[3][2];
				
				break;
			case Mars:
				cm.selectObject("Mars");
				camera3.position.x = camera3Positions[5][0];
				camera3.position.y = camera3Positions[5][1];
				camera3.position.z = camera3Positions[5][2];
				
				break;
			case Jupyter:
				cm.selectObject("Jupiter");
				camera3.position.x = camera3Positions[6][0];
				camera3.position.y = camera3Positions[6][1];
				camera3.position.z = camera3Positions[6][2];
				
				break;
			case Saturn:
				cm.selectObject("Saturn");
				camera3.position.x = camera3Positions[7][0];
				camera3.position.y = camera3Positions[7][1];
				camera3.position.z = camera3Positions[7][2];
				
				break;
			case Uranus:
				cm.selectObject("Uranus");
				camera3.position.x = camera3Positions[8][0];
				camera3.position.y = camera3Positions[8][1];
				camera3.position.z = camera3Positions[8][2];
				
				break;
			case Neptune:
				cm.selectObject("Neptune");
				camera3.position.x = camera3Positions[9][0];
				camera3.position.y = camera3Positions[9][1];
				camera3.position.z = camera3Positions[9][2];
				
				break;
			case Pluto:
				cm.selectObject("Pluto");
				camera3.position.x = camera3Positions[10][0];
				camera3.position.y = camera3Positions[10][1];
				camera3.position.z = camera3Positions[10][2];
				
				break;
			case Sun:
				cm.selectObject("Sun");
				camera3.position.x = camera3Positions[0][0];
				camera3.position.y = camera3Positions[0][1];
				camera3.position.z = camera3Positions[0][2];
				
				break;
			case Moon:
				cm.selectObject("Moon");
				camera3.position.x = camera3Positions[4][0];
				camera3.position.y = camera3Positions[4][1];
				camera3.position.z = camera3Positions[4][2];
				
				break;
			case "Asteroid":
				cm.selectObject("Asteroid");
				camera3.position.x = camera3Positions[12][0];
				camera3.position.y = camera3Positions[12][1];
				camera3.position.z = camera3Positions[12][2];
				break;
			case "Satellite":
				cm.selectObject("Satellite");
				camera3.position.x = camera3Positions[11][0];
				camera3.position.y = camera3Positions[11][1];
				camera3.position.z = camera3Positions[11][2];
				break;
			case "star1":
				cm.selectObject("Star1");
   				deepSpace3.material = new THREE.MeshBasicMaterial({map: new THREE.TextureLoader().load("imgs/" + "nebula.jpg"), depthTest: false});
   				camera3.position.x = camera3Positions[13][0];
				camera3.position.y = camera3Positions[13][1];
				camera3.position.z = camera3Positions[13][2];
				renderer.render(scene3, camera3);
				break;
			case "star2":
				cm.selectObject("Star2");
				deepSpace3.material = new THREE.MeshBasicMaterial({map: new THREE.TextureLoader().load("imgs/" + "universe.jpg"), depthTest: false});
   				camera3.position.x = camera3Positions[13][0];
				camera3.position.y = camera3Positions[13][1];
				camera3.position.z = camera3Positions[13][2];
				renderer.render(scene3, camera3);
				break;
			case "star3":
				cm.selectObject("Star3");
				deepSpace3.material = new THREE.MeshBasicMaterial({map: new THREE.TextureLoader().load("imgs/" + "galaxy2.jpg"), depthTest: false});
   				camera3.position.x = camera3Positions[13][0];
				camera3.position.y = camera3Positions[13][1];
				camera3.position.z = camera3Positions[13][2];
				renderer.render(scene3, camera3);
				break;
			case "star4":
				cm.selectObject("Star4");
				deepSpace3.material = new THREE.MeshBasicMaterial({map: new THREE.TextureLoader().load("imgs/" + "bigbang.jpg"), depthTest: false});
   				camera3.position.x = camera3Positions[13][0];
				camera3.position.y = camera3Positions[13][1];
				camera3.position.z = camera3Positions[13][2];
				renderer.render(scene3, camera3);
				break;
			case "star5":
				cm.selectObject("Star5");
				deepSpace3.material = new THREE.MeshBasicMaterial({map: new THREE.TextureLoader().load("imgs/" + "milkyway.jpg"), depthTest: false});
   				camera3.position.x = camera3Positions[13][0];
				camera3.position.y = camera3Positions[13][1];
				camera3.position.z = camera3Positions[13][2];
				renderer.render(scene3, camera3);
				break;
			case "star6":
				cm.selectObject("Star6");
				deepSpace3.material = new THREE.MeshBasicMaterial({map: new THREE.TextureLoader().load("imgs/" + "blackhole.jpg"), depthTest: false});
   				camera3.position.x = camera3Positions[13][0];
				camera3.position.y = camera3Positions[13][1];
				camera3.position.z = camera3Positions[13][2];
				break;
			default:
				//cm.selectObject("Pluto");
		}
	}
}

function playAnimation(){
	rotating = true;
}

function pauseAnimation(){
	rotating = false;
}

function galaxyScene(){
	sceneOnUse = scene2;
	cameraOnUse = camera2;
	controls.reset();
	scene.remove(camera);
	//controls.enabled = false;
	scene2.add(camera2);
	scene.remove(solarSystem); 
	galaxy = true;
}

function solarScene(){
	cm.selectObject("Sun");
	camera3.position.x = camera3Positions[0][0];
	camera3.position.y = camera3Positions[0][1];
	camera3.position.z = camera3Positions[0][2];
	selected = sun;
	sceneOnUse = scene;
	cameraOnUse = camera;
	controls.reset();
	scene2.remove(camera2);
	scene.add(camera);
	galaxy = false;
	scene.add(solarSystem);

	deepSpace3.material = new THREE.MeshBasicMaterial({map: new THREE.TextureLoader().load("imgs/" + "black-map.jpg"), depthTest: false});
}


function addObj() {
    var loader = new THREE.OBJLoader();
    var filename = "imgs/space_station.obj";

    
	manager = new THREE.LoadingManager();
	manager.onProgress = function (item, loaded, total) {
	console.log(item, loaded, total);
	};
	var texture = new THREE.Texture();
	var loader = new THREE.OBJLoader(manager);
	loader.load(filename, function (object) {
	mesh = new THREE.Mesh( object.children[0].geometry, new THREE.MeshBasicMaterial({map: new THREE.TextureLoader().load("imgs/space_station_map_2.jpg"), transparent: true}));
	satellite = mesh;

	mesh.scale.x=0.00015;
	mesh.scale.y=0.00015;
	mesh.scale.z=0.00015;


	mesh.position.x = earth.position.x - 2.5;
	earth.add(satellite);
	satellite.constructor = "Satellite";
	renderer.render(scene, camera);
	});
  }


function addObj2() {
    var loader = new THREE.OBJLoader();
    var filename = "imgs/space_station.obj";

    
	manager = new THREE.LoadingManager();
	manager.onProgress = function (item, loaded, total) {
	console.log(item, loaded, total);
	};
	var texture = new THREE.Texture();
	var loader = new THREE.OBJLoader(manager);
	loader.load(filename, function (object) {
	mesh = new THREE.Mesh( object.children[0].geometry, new THREE.MeshBasicMaterial({map: new THREE.TextureLoader().load("imgs/space_station_map_2.jpg"), transparent: true}));
	satellite2 = mesh;

	mesh.scale.x=0.00035;
	mesh.scale.y=0.00035;
	mesh.scale.z=0.00035;


	mesh.position.x = sun2.position.x - 12.;
	objectsToExplain.add(satellite2);
	renderer.render(scene3, camera3);
	});
  }

  function addObj1() {
    var loader = new THREE.OBJLoader();
    var filename = "imgs/asteroid.obj";

    
	manager = new THREE.LoadingManager();
	manager.onProgress = function (item, loaded, total) {
	console.log(item, loaded, total);
	};
	var texture = new THREE.Texture();
	var loader = new THREE.OBJLoader(manager);
	loader.load(filename, function (object) {
	mesh = new THREE.Mesh( object.children[0].geometry, new THREE.MeshBasicMaterial({map: new THREE.TextureLoader().load("imgs/asteroid-map.jpg"), transparent: true}));
	asteroid = mesh;



	mesh.scale.x=0.01;
	mesh.scale.y=0.01;
	mesh.scale.z=0.01;
	mesh.position.x = earth.position.x - 15;
	pivot.add(asteroid);
	asteroid.position.x = 17;
	asteroid.position.y = 1.25;
	asteroid.constructor = "Asteroid";
	renderer.render(scene, camera);
	});
  }

  function addObj3() {
    var loader = new THREE.OBJLoader();
    var filename = "imgs/asteroid.obj";

    
	manager = new THREE.LoadingManager();
	manager.onProgress = function (item, loaded, total) {
	console.log(item, loaded, total);
	};
	var texture = new THREE.Texture();
	var loader = new THREE.OBJLoader(manager);
	loader.load(filename, function (object) {
	mesh = new THREE.Mesh( object.children[0].geometry, new THREE.MeshBasicMaterial({map: new THREE.TextureLoader().load("imgs/asteroid-map.jpg"), transparent: true}));
	asteroid2 = mesh;

	mesh.scale.x=0.035;
	mesh.scale.y=0.035;
	mesh.scale.z=0.035;


	mesh.position.x = sun2.position.x - 19.;
	objectsToExplain.add(asteroid2);
	renderer.render(scene3, camera3);
	});
  }