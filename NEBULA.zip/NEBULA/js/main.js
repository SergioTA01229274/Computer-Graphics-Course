"use strict"
var canvas;
var renderer, renderer2;
var scene, scene2, scene3, sceneBackground;
var camera, camera2, camera3, cameraBackground;
var light, light2, light3, lightBackground, lightBackground2, lightBackground3;
var deepSpace, sun, earth, moon, apolo, mercury, venus, mars, jupyter, saturn, uranus, neptune, pluto;
var solarSystem, earthOrbit, moonOrbit, apoloOrbit, mercuryOrbit, venusOrbit, marsOrbit, jupyterOrbit, saturnOrbit, uranusOrbit, neptuneOrbit, plutoOrbit;
var rotating;
var raycaster;
var mouse = new THREE.Vector2();
var selected;
var satellite;
var galaxy = true;
var deepSpace2, deepSpace3;
var sceneBackground2, cameraBackground2, sceneBackground3, cameraBackground3;
var controls;
var sun2, earth2, moon2, apolo2, mercury2, venus2, mars2, jupyter2, saturn2, uranus2, neptune2, pluto2;
var objectsToExplain;
var camera3Positions;
var cm;
var saturnRing, saturnRing2, asteroid, astePo, pivot;
var satellite2, asteroid2;
var galaxyView, star1, star2, star3, star4, star5, star6;
var cameraOnUse, sceneOnUse;

class Group extends THREE.Group
{
    constructor()
    {
        super();
    }
}

class Model extends THREE.Mesh
{
    constructor(geometry, material)
    {
        super(geometry, material);
    }
     setTextureMaterial()
    {
         this.material = new THREE.MeshBasicMaterial({map: new THREE.TextureLoader().load("imgs/" + this.imageTexture), transparent: true});
    }
}

class SphereModel extends Model
{
    constructor()
    {
        super(new THREE.SphereGeometry(2.5, 11, 11), new THREE.MeshBasicMaterial({wireframe: true}));
    }
}

class Star extends SphereModel
{
    constructor()
    {
        super();
    }
}

class SphereSun extends Model
{
    constructor()
    {
        super(new THREE.SphereGeometry(2, 11, 11), new THREE.MeshBasicMaterial({wireframe: true}));
    }
}

class Sun extends SphereSun
{
    constructor()
    {
        super();
        this.ownRotation = 0.01;
        this.radius = 2.;
        this.imageTexture = "sun-map.jpg";
    }
}

class Planet extends SphereModel
{
    constructor()
    {
        super();
    }
}

class Earth extends Planet
{
    constructor()
    {
        super();
        this.ownRotation = 0.01;
        this.radius = 0.2;
        this.distanceToParent = 5.5;
        this.rotationAboutParent= 0.0155;
        this.imageTexture = "earth-map.jpg";
    }
}


class Mercury extends Planet
{
    constructor()
    {
        super();
        this.ownRotation = 0.01;
        this.radius = 0.20 * (.36);
        this.distanceToParent = 2.5;
        this.rotationAboutParent= 0.025;
        this.imageTexture = "mercury-map.jpg";
    }
}

class Venus extends Planet
{
    constructor()
    {
        super();
        this.ownRotation = 0.01;
        this.radius = 0.20 * (.9);
        this.distanceToParent = 3.75;
        this.rotationAboutParent= 0.0182;
        this.imageTexture = "venus-map.jpg";
    }
}

class Mars extends Planet
{
    constructor()
    {
        super();
        this.ownRotation = 0.01;
        this.radius = 0.20 * (.5);
        this.distanceToParent = 7.25;
        this.rotationAboutParent= 0.0125;
        this.imageTexture = "mars-map.jpg";
    }
}

class Jupyter extends Planet
{
    constructor()
    {
        super();
        this.ownRotation = 0.01;
        this.radius = 0.20 * (1.5);
        this.distanceToParent = 9.;
        this.rotationAboutParent= 0.0068;
        this.imageTexture = "jupyter-map.jpg";
    }
}

class Saturn extends Planet
{
    constructor()
    {
        super();
        this.ownRotation = 0.01;
        this.radius = 0.20 * (1.25);
        this.distanceToParent = 11.25;
        this.rotationAboutParent= 0.0050;
        this.imageTexture = "saturn-map.jpg";
    }
}

class Uranus extends Planet
{
    constructor()
    {
        super();
        this.ownRotation = 0.01;
        this.radius = 0.20 * (.75);
        this.distanceToParent = 13.;
        this.rotationAboutParent= 0.0035;
        this.imageTexture = "uranus-map.jpg";
    }
}

class Neptune extends Planet
{
    constructor()
    {
        super();
        this.ownRotation = 0.01;
        this.radius = 0.20 * (1.);
        this.distanceToParent = 14.5;
        this.rotationAboutParent= 0.0028;
        this.imageTexture = "neptune-map.jpg";
    }
}
class Pluto extends Planet
{
    constructor()
    {
        super();
        this.ownRotation = 0.01;
        this.radius = 0.20 * (.2);
        this.distanceToParent = 15.75;
        this.rotationAboutParent= 0.0022;
        this.imageTexture = "pluto-map.jpg";
    }
}


class Satellite extends SphereModel
{
    constructor()
    {
        super();
    }
}

class Moon extends Satellite
{
    constructor()
    {
        super();
        this.ownRotation = 0.01;
        this.radius = 0.2  *(0.2) ;
        this.distanceToParent = 1.;
        this.rotationAboutParent= 0.01;
        this.imageTexture = "moon-map.jpg";
    }
}

class Apolo extends Satellite
{
    constructor()
    {
        super();
        this.ownRotation = 0.01;
        this.radius = 0.05;
        this.distanceToParent = .35;
        this.rotationAboutParent= 0.01;
        this.imageTexture = undefined;
    }
}

function main()
{ 

    // BACKGROUND SOUND
    var sound = document.getElementById("bgMusic");
    sound.loop = true;
    sound.load();
    sound.play();

    cm = new CardManager("cardObject");
    cm.selectObject("Sun");

    // CANVAS
    canvas = document.getElementById("canvas");
    resizeCanvas();     // Set canvas size for the first time

    // SECOND CANVAS
    var miniDiv = document.getElementById("miniCanvas2Div");
    var canvas2 = document.getElementById("miniCanvas2");
    canvas2.width = miniDiv.offsetWidth;
    canvas2.height = miniDiv.offsetHeight + 50;

    // RENDERER2
    renderer2 = new THREE.WebGLRenderer({canvas: canvas2});
    renderer2.setSize(canvas2.width, canvas2.height);
    renderer2.setClearColor("black"); 

    // RENDERER
    renderer = new THREE.WebGLRenderer({canvas: canvas});
    renderer.setSize(canvas.width, canvas.height);
    renderer.setClearColor("black");                   

    rotating = false;
    raycaster = new THREE.Raycaster();

    // MODELS
    deepSpace3 = new THREE.Mesh(new THREE.PlaneGeometry(2, 2, 0), new THREE.MeshBasicMaterial({map: new THREE.TextureLoader().load("imgs/" + "black-map.jpg"), depthTest: false}));
    deepSpace2 = new THREE.Mesh(new THREE.PlaneGeometry(2, 2, 0), new THREE.MeshBasicMaterial({map: new THREE.TextureLoader().load("imgs/" + "galaxy_back.jpg"), depthTest: false}));
    deepSpace = new THREE.Mesh(new THREE.PlaneGeometry(2, 2, 0), new THREE.MeshBasicMaterial({map: new THREE.TextureLoader().load("imgs/" + "galaxy.jpg"), depthTest: false}));
    
    camera3Positions = [];
    objectsToExplain = new Group();
    galaxyView = new Group();
    sun2 = new Sun();
    sun2.position.x = sun2.position.x - 10;
    earth2 = new Earth();
    moon2 = new Moon();
    mercury2 = new Mercury();
    venus2 = new Venus();
    mars2 = new Mars();
    jupyter2 = new Jupyter();
    saturn2 = new Saturn();
    uranus2 = new Uranus();
    neptune2 = new Neptune();
    pluto2 = new Pluto();

    solarSystem = new Group();
    earthOrbit = new Group();
    moonOrbit = new Group();
    //apoloOrbit = new Group();
    mercuryOrbit = new Group();
    venusOrbit = new Group();
    marsOrbit = new Group();
    jupyterOrbit = new Group();
    saturnOrbit = new Group();
    uranusOrbit = new Group();
    neptuneOrbit = new Group();
    plutoOrbit = new Group();
    pivot = new Group();
    pivot.position.set(0,0,13);
    
    mercury = new Mercury();
    venus = new Venus();
    mars = new Mars();
    jupyter = new Jupyter();
    saturn = new Saturn();
    uranus = new Uranus();
    neptune = new Neptune();
    pluto = new Pluto();

    sun = new Sun();
    earth = new Earth();
    moon = new Moon();
    //apolo = new Apolo();


    var mercuryOrbitGuide = new THREE.Mesh(new THREE.TorusBufferGeometry(2.5, 0.005, 30, 200), new THREE.MeshBasicMaterial({color:"white"}));
    mercuryOrbitGuide.rotation.x = Math.PI / 2;

    var venusOrbitGuide = new THREE.Mesh(new THREE.TorusBufferGeometry(3.75, 0.005, 30, 200), new THREE.MeshBasicMaterial({color:"white"}));
    venusOrbitGuide.rotation.x = Math.PI / 2;

    var earthOrbitGuide = new THREE.Mesh(new THREE.TorusBufferGeometry(5.5, 0.005, 30, 200), new THREE.MeshBasicMaterial({color:"white"}));
    earthOrbitGuide.rotation.x = Math.PI / 2;

    var marsOrbitGuide = new THREE.Mesh(new THREE.TorusBufferGeometry(7.25, 0.005, 30, 200), new THREE.MeshBasicMaterial({color:"white"}));
    marsOrbitGuide.rotation.x = Math.PI / 2;

    var jupyterOrbitGuide = new THREE.Mesh(new THREE.TorusBufferGeometry(9., 0.005, 30, 200), new THREE.MeshBasicMaterial({color:"white"}));
    jupyterOrbitGuide.rotation.x = Math.PI / 2;

    var saturnOrbitGuide = new THREE.Mesh(new THREE.TorusBufferGeometry(11.25, 0.005, 30, 200), new THREE.MeshBasicMaterial({color:"white"}));
    saturnOrbitGuide.rotation.x = Math.PI / 2;

    var uranusOrbitGuide = new THREE.Mesh(new THREE.TorusBufferGeometry(13., 0.005, 30, 200), new THREE.MeshBasicMaterial({color:"white"}));
    uranusOrbitGuide.rotation.x = Math.PI / 2;

    var neptuneOrbitGuide = new THREE.Mesh(new THREE.TorusBufferGeometry(14.5, 0.005, 30, 200), new THREE.MeshBasicMaterial({color:"white"}));
    neptuneOrbitGuide.rotation.x = Math.PI / 2;

    var plutoOrbitGuide = new THREE.Mesh(new THREE.TorusBufferGeometry(15.75, 0.005, 30, 200), new THREE.MeshBasicMaterial({color:"white"}));
    plutoOrbitGuide.rotation.x = Math.PI / 2;
    //mercuryOrbitGuide.position.y = 1.;
    //mercuryOrbitGuide.position.x = 0.;
    saturnRing = new THREE.Mesh(new THREE.TorusBufferGeometry(0.20 * (1.25) + 0.75, 0.15, 2, 20), new THREE.MeshBasicMaterial({map:new THREE.TextureLoader().load("imgs/saturn-ring.jpg"), transparent: true}));
    saturnRing.rotation.x = Math.PI / 4;
    saturnRing.position.x = saturn.distanceToParent;
    
    saturnRing2 = new THREE.Mesh(new THREE.TorusBufferGeometry(0.20 * (1.25) + 0.55, 0.10, 2, 20), new THREE.MeshBasicMaterial({map:new THREE.TextureLoader().load("imgs/saturn-ring.jpg"), transparent: true}));
    saturnRing2.rotation.x = 0 * Math.PI / 180;
    saturnRing2.rotation.y = 50 * Math.PI / 180;
    

    saturnRing2.position.x = saturn2.position.x + saturn2.distanceToParent + 14.;
    saturnRing2.position.y = saturn2.position.y + 0.05;


    //stars

    star1 = new THREE.Mesh(new THREE.OctahedronBufferGeometry(.15), new THREE.MeshBasicMaterial({map: new THREE.TextureLoader().load("imgs/gold-map.jpg"), transparent: true}));
    star2 = new THREE.Mesh(new THREE.OctahedronBufferGeometry(.15), new THREE.MeshBasicMaterial({map: new THREE.TextureLoader().load("imgs/gold-map.jpg"), transparent: true}));
    star3 = new THREE.Mesh(new THREE.OctahedronBufferGeometry(.15), new THREE.MeshBasicMaterial({map: new THREE.TextureLoader().load("imgs/gold-map.jpg"), transparent: true}));
    star4 = new THREE.Mesh(new THREE.OctahedronBufferGeometry(.15), new THREE.MeshBasicMaterial({map: new THREE.TextureLoader().load("imgs/gold-map.jpg"), transparent: true}));
    star5 = new THREE.Mesh(new THREE.OctahedronBufferGeometry(.15), new THREE.MeshBasicMaterial({map: new THREE.TextureLoader().load("imgs/gold-map.jpg"), transparent: true}));
    star6 = new THREE.Mesh(new THREE.OctahedronBufferGeometry(.15), new THREE.MeshBasicMaterial({map: new THREE.TextureLoader().load("imgs/gold-map.jpg"), transparent: true}));

    star1.position.x = -3;
    star1.position.y = 2;
    star1.constructor = "star1";
    star2.constructor = "star2";
    star3.constructor = "star3";
    star4.constructor = "star4";
    star5.constructor = "star5";


    star3.position.x = -2.5;
    star3.position.y = -1;

    star4.position.x = 1.5;
    star4.position.y = .75;


    star5.position.x = 4.;
    star5.position.y = 1.3;

    star2.position.x = 3;
    star2.position.y = -1.3;

    star6.constructor = "star6";

    selected = sun;
    satellite = earth;
    asteroid = moon;

    satellite2 = earth2;
    asteroid2 = moon2;

    sun.setTextureMaterial();
    sun2.setTextureMaterial();
    mercury2.setTextureMaterial();
    venus2.setTextureMaterial();
    earth2.setTextureMaterial();
    moon2.setTextureMaterial();
    mars2.setTextureMaterial();
    jupyter2.setTextureMaterial();
    saturn2.setTextureMaterial();
    uranus2.setTextureMaterial();
    neptune2.setTextureMaterial();
    pluto2.setTextureMaterial();  


    earth.setTextureMaterial();
    moon.setTextureMaterial();
    //apolo.setWireframeMaterial();
    mercury.setTextureMaterial();
    venus.setTextureMaterial();
    mars.setTextureMaterial();
    jupyter.setTextureMaterial();
    saturn.setTextureMaterial();
    uranus.setTextureMaterial();
    neptune.setTextureMaterial();
    pluto.setTextureMaterial();

    // LOCAL MODEL TRANSFORMS
    // EARTH
    earth.position.x = earth.position.x + earth.distanceToParent;
    earth.scale.set(earth.radius, earth.radius, earth.radius);

    earth2.position.x = earth2.position.x + earth2.distanceToParent + 2;
    earth2.scale.set(earth2.radius, earth2.radius, earth2.radius);

    
    // MOON ORBIT
    moonOrbit.position.x = moonOrbit.position.x + earth.distanceToParent;
    // MOON
    moon.position.x = moon.position.x + moon.distanceToParent;
    moon.scale.set(moon.radius, moon.radius, moon.radius);

    moon2.position.x = moon2.position.x + moon2.distanceToParent - 18;
    moon2.scale.set(moon2.radius, moon2.radius, moon2.radius);
    // APOLO ORBIT
    //apoloOrbit.position.x = apoloOrbit.position.x + moon.distanceToParent;
    // APOLO
   // apolo.position.x = apolo.position.x + apolo.distanceToParent;
    //apolo.scale.set(apolo.radius, apolo.radius, apolo.radius);
    //mercury
    mercury.position.x = mercury.position.x + mercury.distanceToParent;
    mercury.scale.set(mercury.radius, mercury.radius, mercury.radius);
    
    mercury2.position.x = mercury2.position.x + mercury2.distanceToParent - 6;
    mercury2.scale.set(mercury2.radius, mercury2.radius, mercury2.radius);

    //venus
    venus.position.x = venus.position.x + venus.distanceToParent;
    venus.scale.set(venus.radius, venus.radius, venus.radius);

    venus2.position.x = venus2.position.x + venus2.distanceToParent - 2;
    venus2.scale.set(venus2.radius, venus2.radius, venus2.radius);

    //mars
    mars.position.x = mars.position.x + mars.distanceToParent;
    mars.scale.set(mars.radius, mars.radius, mars.radius);

    mars2.position.x = mars2.position.x + mars2.distanceToParent + 6;
    mars2.scale.set(mars2.radius, mars2.radius, mars2.radius);

    //jupyter
    jupyter.position.x = jupyter.position.x + jupyter.distanceToParent;
    jupyter.scale.set(jupyter.radius, jupyter.radius, jupyter.radius);


    jupyter2.position.x = jupyter2.position.x + jupyter2.distanceToParent + 10;
    jupyter2.scale.set(jupyter2.radius, jupyter2.radius, jupyter2.radius);
    //saturn
    saturn.position.x = saturn.position.x + saturn.distanceToParent;
    saturn.scale.set(saturn.radius, saturn.radius, saturn.radius);

    saturn2.position.x = saturn2.position.x + saturn2.distanceToParent + 14;
    saturn2.scale.set(saturn2.radius, saturn2.radius, saturn2.radius);

    //uranus
    uranus.position.x = uranus.position.x + uranus.distanceToParent;
    uranus.scale.set(uranus.radius, uranus.radius, uranus.radius);

    uranus2.position.x = uranus2.position.x + uranus2.distanceToParent + 18;
    uranus2.scale.set(uranus2.radius, uranus2.radius, uranus2.radius);
    //neptune
    neptune.position.x = neptune.position.x + neptune.distanceToParent;
    neptune.scale.set(neptune.radius, neptune.radius, neptune.radius);

    neptune2.position.x = neptune2.position.x + neptune2.distanceToParent + 22;
    neptune2.scale.set(neptune2.radius, neptune2.radius, neptune2.radius);
    //pluto
    pluto.position.x = pluto.position.x + pluto.distanceToParent;
    pluto.scale.set(pluto.radius, pluto.radius, pluto.radius);

    pluto2.position.x = pluto2.position.x + pluto2.distanceToParent + 26;
    pluto2.scale.set(pluto2.radius, pluto2.radius, pluto2.radius);

    // LIGHTS 
    // BACKGROUND CAMERA
    lightBackground = new THREE.PointLight(0xaaaaaa);
    lightBackground.position.set(-100,200,100);

    light = new THREE.AmbientLight();   
    light2 = new THREE.AmbientLight();   
    light3 = new THREE.AmbientLight();   

    // CAMERAS

    // FRONT CAMERA
    camera = new THREE.PerspectiveCamera(60., canvas.width / canvas.height, 0.01, 10000.);  // CAMERA SOLAR
    camera2 = new THREE.PerspectiveCamera(60., canvas.width / canvas.height, 0.01, 10000.);  // CAMERA GALAXY
    camera3 = new THREE.PerspectiveCamera(60., canvas.width / canvas.height, 0.01, 10000.);  // CAMERA GALAXY

    cameraOnUse = camera2;
    camera3Positions.push([-10, 0., 5.]); // sun
    camera3Positions.push([-3.5, 0., 2.]); // mercury
    camera3Positions.push([1.75, 0., 2.]); // venus
    camera3Positions.push([7.5, 0., 2.]); // earth
    camera3Positions.push([-17., 0., 1.]); // moon
    camera3Positions.push([13.25, 0., 2.]); //mars
    camera3Positions.push([18.75, 0., 2.]); //jupyter
    camera3Positions.push([25.25, 0., 2.]); //saturn
    camera3Positions.push([31, 0., 2.]); //uranus
    camera3Positions.push([36.5, 0., 2.]); //neptune
    camera3Positions.push([41.75, 0., 0.5]); //pluto
    camera3Positions.push([-22.25, 0., 2.]); //ISS
    camera3Positions.push([-29.25, 0., 2.]); //Comet
    camera3Positions.push([60, 0., 2.]); //Images


    camera3.position.x = camera3Positions[0][0];
    camera3.position.y = camera3Positions[0][1];
    camera3.position.z = camera3Positions[0][2];

    camera3.rotation.x = 0. * Math.PI /180;
    camera3.rotation.y = 0. ;
    camera3.rotation.z = 0. ;     


    camera.position.set(0., 0., 6.);    
    camera.position.x = 0.;
    camera.position.y = 1.5;
    camera.position.z = 19.545573367058513;

    camera.rotation.x = 0. * Math.PI /180;
    camera.rotation.y = 0. ;
    camera.rotation.z = 0. ;       
    controls = new THREE.OrbitControls(camera, renderer.domElement);

    // SCENE GRAPH

    // BACKGROUND SCENE GRAPH
    sceneBackground = new THREE.Scene();
    cameraBackground = new THREE.Camera();
    sceneBackground.add(deepSpace);
    sceneBackground.add(cameraBackground);
    sceneBackground.add(lightBackground);  


    lightBackground2 = new THREE.PointLight(0xaaaaaa);
    lightBackground2.position.set(-100,200,100);

    lightBackground3 = new THREE.PointLight(0xaaaaaa);
    lightBackground3.position.set(-100,200,100);


    sceneBackground2 = new THREE.Scene();
    cameraBackground2 = new THREE.Camera();
    sceneBackground2.add(deepSpace2);
    sceneBackground2.add(cameraBackground2);
    sceneBackground2.add(lightBackground2);  

    sceneBackground3 = new THREE.Scene();
    cameraBackground3 = new THREE.Camera();
    sceneBackground3.add(deepSpace3);
    sceneBackground3.add(cameraBackground3);
    sceneBackground3.add(lightBackground3);



    // FRONT SCENE GRAPH
    scene = new THREE.Scene(); 
    scene2 = new THREE.Scene();
    scene3 = new THREE.Scene();

    sceneOnUse = scene2;

    scene3.add(objectsToExplain);
    objectsToExplain.add(sun2);
    objectsToExplain.add(mercury2);
    objectsToExplain.add(venus2);
    objectsToExplain.add(earth2);
    objectsToExplain.add(moon2);
    objectsToExplain.add(mars2);
    objectsToExplain.add(jupyter2);
    objectsToExplain.add(saturn2);
    objectsToExplain.add(uranus2);
    objectsToExplain.add(neptune2);
    objectsToExplain.add(pluto2);
    objectsToExplain.add(saturnRing2);

    scene2.add(galaxyView);
    galaxyView.add(star1);
    galaxyView.add(star2);
    galaxyView.add(star3);
    galaxyView.add(star4);
    galaxyView.add(star5);
    galaxyView.add(star6);
    camera2.lookAt(0,0,0);
    camera2.position.set(0,0,5);

    //scene.add(solarSystem);  
    solarSystem.add(sun);
    solarSystem.add(earthOrbit);
    solarSystem.add(mercuryOrbit);
    solarSystem.add(venusOrbit);
    solarSystem.add(marsOrbit);
    solarSystem.add(jupyterOrbit);
    solarSystem.add(saturnOrbit);
    solarSystem.add(uranusOrbit);
    solarSystem.add(neptuneOrbit);
    solarSystem.add(plutoOrbit);
    solarSystem.add(pivot);

    scene.add(earthOrbitGuide);
    scene.add(mercuryOrbitGuide);
    scene.add(venusOrbitGuide);
    scene.add(marsOrbitGuide);
    scene.add(jupyterOrbitGuide);
    scene.add(saturnOrbitGuide);
    scene.add(uranusOrbitGuide);
    scene.add(neptuneOrbitGuide);
    scene.add(plutoOrbitGuide);

    earthOrbit.add(earth);
    earthOrbit.add(moonOrbit);
    moonOrbit.add(moon);
    mercuryOrbit.add(mercury);
    venusOrbit.add(venus);
    marsOrbit.add(mars);
    jupyterOrbit.add(jupyter);
    saturnOrbit.add(saturn);
    saturnOrbit.add(saturnRing);
    uranusOrbit.add(uranus);
    neptuneOrbit.add(neptune);
    plutoOrbit.add(pluto);

    scene.add(light);  
    scene2.add(light2);
    scene3.add(light3);

    earthOrbit.rotation.y = 0.;
    //apoloOrbit.rotation.y = apoloOrbit.rotation.y + apolo.rotationAboutParent;
    mercuryOrbit.rotation.y = 0;
    venusOrbit.rotation.y = -50;
    marsOrbit.rotation.y = 100;
    jupyterOrbit.rotation.y = 400;
    saturnOrbit.rotation.y = 250;
    uranusOrbit.rotation.y = -300;
    neptuneOrbit.rotation.y = 280;
    plutoOrbit.rotation.y = 300;

    // EVENT-HANDLERS
    window.addEventListener('resize', windowEventListener, false);
    window.addEventListener('click', onClick, false);

    addObj();
    addObj1();
    addObj2();
    addObj3();
    // ACTION
    requestAnimationFrame(renderLoop);              // RENDER LOOP
    renderer.autoClear = true;
    renderer.render(scene, camera);
    //renderer2.autoClear = true;
    //renderer2.render(scene,camera);

    //prevent canvas from being erased with next .render call
    renderer.autoClear = false;

    //just render scene2 on top of scene1
    renderer.render(scene2, camera2);
    renderer.render(scene3, camera3);

}

function update()
{
    sun.rotation.y = sun.rotation.y + sun.ownRotation;
    earth.rotation.y = earth.rotation.y + earth.ownRotation;
    moon.rotation.y = moon.rotation.y + moon.ownRotation;
    mercury.rotation.y = mercury.rotation.y + mercury.ownRotation;
    venus.rotation.y = venus.rotation.y + venus.ownRotation;
    mars.rotation.y = mars.rotation.y + mars.ownRotation;
    jupyter.rotation.y = jupyter.rotation.y + jupyter.ownRotation;
    saturn.rotation.y = saturn.rotation.y + saturn.ownRotation;
    uranus.rotation.y = uranus.rotation.y + uranus.ownRotation;
    neptune.rotation.y = neptune.rotation.y + neptune.ownRotation;
    pluto.rotation.y = pluto.rotation.y + pluto.ownRotation;

    sun2.rotation.y = sun2.rotation.y + sun2.ownRotation;
    earth2.rotation.y = earth2.rotation.y + earth2.ownRotation;
    moon2.rotation.y = moon2.rotation.y + moon2.ownRotation;
    mercury2.rotation.y = mercury2.rotation.y + mercury2.ownRotation;
    venus2.rotation.y = venus2.rotation.y + venus2.ownRotation;
    mars2.rotation.y = mars2.rotation.y + mars2.ownRotation;
    jupyter2.rotation.y = jupyter2.rotation.y + jupyter2.ownRotation;
    saturn2.rotation.y = saturn2.rotation.y + saturn2.ownRotation;
    uranus2.rotation.y = uranus2.rotation.y + uranus2.ownRotation;
    neptune2.rotation.y = neptune2.rotation.y + neptune2.ownRotation;
    pluto2.rotation.y = pluto2.rotation.y + pluto2.ownRotation;
    saturnRing2.rotation.y += 0.01;
    saturnRing2.rotation.x += 0.01;
    saturnRing.rotation.y += 0.01;
    saturnRing.rotation.x += 0.01;
    astePo += 0.1;    
    asteroid.rotation.x += .03;
    satellite2.rotation.y += .01;
    asteroid2.rotation.y += .01;    

    //console.log(asteroid.position.x +" "+ asteroid.position.z);

    satellite.rotation.y += 0.001;

    if(rotating){
        earthOrbit.rotation.y = earthOrbit.rotation.y + earth.rotationAboutParent;
        moonOrbit.rotation.y = moonOrbit.rotation.y + moon.rotationAboutParent;
        //apoloOrbit.rotation.y = apoloOrbit.rotation.y + apolo.rotationAboutParent;
        mercuryOrbit.rotation.y = mercuryOrbit.rotation.y + mercury.rotationAboutParent;
        venusOrbit.rotation.y = venusOrbit.rotation.y + venus.rotationAboutParent;
        marsOrbit.rotation.y = marsOrbit.rotation.y + mars.rotationAboutParent;
        jupyterOrbit.rotation.y = jupyterOrbit.rotation.y + jupyter.rotationAboutParent;
        saturnOrbit.rotation.y = saturnOrbit.rotation.y + saturn.rotationAboutParent;
        uranusOrbit.rotation.y = uranusOrbit.rotation.y + uranus.rotationAboutParent;
        neptuneOrbit.rotation.y = neptuneOrbit.rotation.y + neptune.rotationAboutParent;
        plutoOrbit.rotation.y = plutoOrbit.rotation.y + pluto.rotationAboutParent;
        pivot.rotation.y += 0.005;
            

    }

}
       
function renderLoop() 
{
    star1.rotation.y += .01;
    star1.rotation.x += .01;
    star2.rotation.y += .01;
    star2.rotation.x += .01;
    star3.rotation.y += .01;
    star3.rotation.x += .01;
    star4.rotation.y += .01;
    star4.rotation.x += .01;
    star5.rotation.y += .01;
    star5.rotation.x += .01;
    star6.rotation.y += .01;
    star6.rotation.x += .01;
    renderer2.autoClear = false;
    renderer2.clear();
    renderer2.render(sceneBackground3, cameraBackground3);
    renderer2.render(scene3, camera3);
    if (galaxy){
        renderer.autoClear = false;
        renderer.clear();
        renderer.render(sceneBackground2, cameraBackground2);
        renderer.render(scene2, camera2);
        requestAnimationFrame(renderLoop);
    }else{    
        renderer.autoClear = false;
        renderer.clear();
        renderer.render(sceneBackground, cameraBackground);
        renderer.render(scene, camera);

        update();
        requestAnimationFrame(renderLoop);
    }

}



