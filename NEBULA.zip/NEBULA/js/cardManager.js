class CardManager {
    constructor(cardId) {
        this.card = cardId;
    }

    selectObject(object) {
        if (db[object].type == "planet") {
            document.getElementById(this.card+'-content').innerHTML = `
                <p class="header white-text">`+db[object].name+`</p>
                <div class="meta">
                <span class="date" white-text>`+db[object].origin+`</span>
                </div>
                <div class="description white-text">
                    `+db[object].description+` 
                </div>`;
            document.getElementById(this.card+'-extra1').innerHTML = "<strong>Discovery: </strong>" + db[object].discovery;
            document.getElementById(this.card+'-extra2').innerHTML = "<strong>Diameter: </strong>" + db[object].diameter;
            document.getElementById(this.card+'-extra3').innerHTML = "<strong>Orbit: </strong>" + db[object].orbit;
            document.getElementById(this.card+'-extra4').innerHTML = "<strong>Day: </strong>" + db[object].day;
        } else if(db[object].type == "sun") {
            document.getElementById(this.card+'-content').innerHTML = `
                <p class="header white-text">`+db[object].name+`</p>
                <div class="description white-text">
                    `+db[object].description+` 
                </div>`;
            document.getElementById(this.card+'-extra1').innerHTML = "<strong>Diameter: </strong>" + db[object].diameter;
            document.getElementById(this.card+'-extra2').innerHTML = "<strong>Temperature: </strong>" + db[object].temperature;
            document.getElementById(this.card+'-extra3').innerHTML = "<strong>Composition: </strong>" + db[object].composition;
        } else if(db[object].type == "moon") {
            document.getElementById(this.card+'-content').innerHTML = `
                <p class="header white-text">`+db[object].name+`</p>
                <div class="description white-text">
                    `+db[object].description+` 
                </div>`;
            document.getElementById(this.card+'-extra1').innerHTML = "<strong>Distance: </strong>" + db[object].distance;
            document.getElementById(this.card+'-extra2').innerHTML = "<strong>Day: </strong>" + db[object].day;
            document.getElementById(this.card+'-extra3').innerHTML = "<strong>Min Temperature: </strong>" + db[object].minTemp;
            document.getElementById(this.card+'-extra4').innerHTML = "<strong>Max Temperature: </strong>" + db[object].maxTemp;
        } else if(db[object].type == "asteroid") {
            document.getElementById(this.card+'-content').innerHTML = `
                <p class="header white-text">`+db[object].name+`</p>
                <div class="description white-text">
                    `+db[object].description+` 
                </div>`;

            document.getElementById(this.card+'-extra1').innerHTML = "<strong>Comet: </strong>" + db[object].comet;
            document.getElementById(this.card+'-extra2').innerHTML = "<strong>Orbit: </strong>" + db[object].orbit;
            document.getElementById(this.card+'-extra3').innerHTML = "<strong>Seen: </strong>" + db[object].seen;
            document.getElementById(this.card+'-extra4').innerHTML = "<strong>Last Seen: </strong>" + db[object].lastSeen;
            document.getElementById(this.card+'-extra5').innerHTML = "<strong>Next Seen: </strong>" + db[object].nextSeen;
        } else if(db[object].type == "satellite") {
            document.getElementById(this.card+'-content').innerHTML = `
                <p class="header white-text">`+db[object].name+`</p>
                <div class="description white-text">
                    `+db[object].description+` 
                </div>`;
            document.getElementById(this.card+'-extra1').innerHTML = "<strong>Orbits: </strong>" + db[object].flies;
            document.getElementById(this.card+'-extra2').innerHTML = "<strong>Allies: </strong>" + db[object].allies;
            document.getElementById(this.card+'-extra3').innerHTML = "<strong>Crew: </strong>" + db[object].crew;
            document.getElementById(this.card+'-extra4').innerHTML = "<strong></strong>" ;
            document.getElementById(this.card+'-extra5').innerHTML = "</strong>" ;
            
        } else if(db[object].type == "star") {
            document.getElementById(this.card+'-content').innerHTML = `
                <p class="header white-text">`+db[object].name+`</p>
                <div class="description white-text">
                    `+db[object].description+` 
                </div>`;
            document.getElementById(this.card+'-extra1').innerHTML = "<strong></strong>" ;
            document.getElementById(this.card+'-extra2').innerHTML = "<strong></strong>" ;
            document.getElementById(this.card+'-extra3').innerHTML = "<strong></strong>" ;
            document.getElementById(this.card+'-extra4').innerHTML = "<strong></strong>" ;
            document.getElementById(this.card+'-extra5').innerHTML = "</strong>" ;
        }
    }
}